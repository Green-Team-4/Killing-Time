import DramaList from "./DramaList";

const DramaDetail = (props) => {
    
    return (
       
        <div>
            <DramaList/>
        </div>
    );

};

export default DramaDetail;
